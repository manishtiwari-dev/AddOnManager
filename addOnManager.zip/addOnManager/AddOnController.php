<?php

namespace Modules\AddOnManager\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Modules\AddOnManager\Models\AddOn;
use Modules\AddOnManager\Models\AddOnManager;
use Modules\AddOnManager\Models\AddOnSetting;

use App\Models\User;
use App\Models\Country;



class AddOnController extends Controller
{
    public $page = 'addon_manager';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $add_on = AddOn::with('add_on_manager')->get();
        $countrydata = ApiHelper::allSupportCountry();
        $res = [
            'add_on' => $add_on,
            'country' => $countrydata,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }



    public function edit(Request $request)
    {
        $setting_data = ApiHelper::addOnsetting();
        $countrydata = ApiHelper::allSupportCountry();
        $res = [
            'settinglist' => $setting_data,
            'country' => $countrydata

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function update(Request $request)
    {
        foreach (ApiHelper::allSupportCountry() as $key => $value) {
            $saveData = $request->formData;
            if ($saveData) {
                foreach ($saveData as $key => $data) {
                    if (!empty($data)) {
                        $setting_val = (isset($data)) ? $data : '';
                        AddOnSetting::updateOrCreate(
                            ['setting_key' => $key, 'addon_id' => $request->add_on_id],
                            ['setting_value' => $setting_val]
                        );
                    }
                }
            }
        }

        if ($saveData)
            return ApiHelper::JSON_RESPONSE(true, $saveData, 'SUCCESS_ADDON_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_ADDON_UPDATE');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {

        //
    }

    public function ChangeStatus(Request $request)
    {
        $api_token = $request->api_token;

        if (!empty($request->id)) {

            $addOn = AddOnManager::updateOrCreate(
                ['addon_id'   => $request->id],
                ['status' => $request->status]
            );
        }
        return ApiHelper::JSON_RESPONSE(true, $addOn, 'SUCCESS_STATUS_UPDATE');
    }
}
